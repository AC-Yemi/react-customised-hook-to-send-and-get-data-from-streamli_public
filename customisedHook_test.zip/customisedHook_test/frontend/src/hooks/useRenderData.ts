import { useContext } from "react";
import { RenderData } from "streamlit-component-lib";
import { renderDataContext } from "../context/StreamlitProvider";

/**
 * Hook to access `RenderData` from Streamlit.
 *
 * Throws an error if used outside of the `<StreamlitProvider />` context.
 */
export const useRenderData = (): RenderData => {
  const contextValue = useContext(renderDataContext);

  if (contextValue == null) {
    throw new Error(
      "useRenderData() must be used within a <StreamlitProvider />"
    );
  }

  return contextValue;
};
