import React, { useEffect, createContext, useContext } from "react";
import { Streamlit, RenderData } from "streamlit-component-lib";
import { useNullableRenderData } from "../hooks/useNullableRenderData";
import ErrorBoundary from "../utils/ErrorBoundary";

export const renderDataContext = createContext<RenderData | undefined>(
  undefined
);

export const useRenderData = (): RenderData => {
  const contextValue = useContext(renderDataContext);
  if (contextValue == null) {
    throw new Error(
      "useRenderData() must be used inside <StreamlitProvider />"
    );
  }
  return contextValue;
};

const StreamlitProvider: React.FC<{ children: React.ReactNode }> = ({
  children,
}) => {
  const renderData = useNullableRenderData();

  useEffect(() => {
    Streamlit.setFrameHeight();
  });

  if (renderData == null) {
    return null;
  }

  return (
    <ErrorBoundary>
      <renderDataContext.Provider value={renderData}>
        {children}
      </renderDataContext.Provider>
    </ErrorBoundary>
  );
};

export default StreamlitProvider;
