import React, { useState } from "react";

const ErrorBoundary: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [error, setError] = useState<Error | null>(null);

  if (error) {
    return (
      <div>
        <h1>Komponentenfehler</h1>
        <span>{error.message}</span>
      </div>
    );
  }

  return (
    <React.Fragment>
      {React.Children.map(children, (child) =>
        React.cloneElement(child as React.ReactElement, {
          onError: (e: Error) => setError(e),
        })
      )}
    </React.Fragment>
  );
};

export default ErrorBoundary;
