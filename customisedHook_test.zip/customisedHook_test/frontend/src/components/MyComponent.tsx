import React, { useState, useEffect } from "react";
import { Streamlit, RenderData } from "streamlit-component-lib";
import { useNullableRenderData } from "../hooks/useNullableRenderData";
import StreamlitProvider from "../context/StreamlitProvider";

const MyComponent: React.FC = () => {
  const renderData = useNullableRenderData();
  const [input1, setInput1] = useState<number | undefined>(renderData?.args.input1);
  const [input2, setInput2] = useState<number | undefined>(renderData?.args.input2);
  const [result, setResult] = useState<number | undefined>(renderData?.args.result);

  // Sende die Werte an Streamlit, wenn sich input1 oder input2 ändern
  useEffect(() => {
    if (input1 !== undefined && input2 !== undefined) {
      Streamlit.setComponentValue({ input1, input2 });
    }
  }, [input1, input2]);

  // Wenn Streamlit neue Daten bereitstellt, aktualisieren
  useEffect(() => {
    if (renderData?.args.result !== undefined) {
      setResult(renderData.args.result);
    }
  }, [renderData?.args.result]);

  return (
    <StreamlitProvider>
      <div style={{ padding: "1rem", fontFamily: "Arial, sans-serif" }}>
        <h2>Variable input in frontend</h2>
        <div style={{ marginBottom: "1rem" }}>
          <label>
            input1:
            <input
              type="number"
              value={input1 ?? ""}
              onChange={(e) => setInput1(Number(e.target.value))}
            />
          </label>
        </div>
        <div style={{ marginBottom: "1rem" }}>
          <label>
            input2:
            <input
              type="number"
              value={input2 ?? ""}
              onChange={(e) => setInput2(Number(e.target.value))}
            />
          </label>
        </div>

        <div style={{ marginBottom: "1rem" }}>
          <label>
            result:
            <input type="number" value={result ?? ""} readOnly />
          </label>
        </div>
      </div>
    </StreamlitProvider>
  );
};

export default MyComponent;