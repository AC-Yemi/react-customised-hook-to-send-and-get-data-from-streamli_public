import React from "react";
import ReactDOM from "react-dom";
import MyComponent from "./components/MyComponent";
import StreamlitProvider from "./context/StreamlitProvider";

ReactDOM.render(
  <React.StrictMode>
    <StreamlitProvider>
      <MyComponent />
    </StreamlitProvider>
  </React.StrictMode>,
  document.getElementById("root")
);


