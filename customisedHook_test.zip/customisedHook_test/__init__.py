import streamlit as st
import streamlit.components.v1 as components

# Setze das Layout auf 'wide'
st.set_page_config(layout="wide")

# Zeige den Titel der App an
st.title("Test react customised hooks")

# Initialisiere die React-Komponente
my_component = components.declare_component("my_component", url="http://localhost:3001")

# Initialisieren des Session State
if "input1" not in st.session_state:
    st.session_state.input1 = 0
if "input2" not in st.session_state:
    st.session_state.input2 = 0
if "result" not in st.session_state:
    st.session_state.result = 0

# Abrufen und Senden von Daten an die React-Komponente
data = my_component(
    input1=st.session_state.input1,
    input2=st.session_state.input2,
    result=st.session_state.result,  # Senden Sie das berechnete Ergebnis
    key="unique-key"
)

# Anzeigen der empfangenen Daten von der Komponente für Debugging-Zwecke
print("Daten von React-Komponente erhalten:", data)

if data is not None:
    st.session_state.input1 = data.get("input1", st.session_state.input1)
    st.session_state.input2 = data.get("input2", st.session_state.input2)

    # Neuberechnung des Ergebnisses
    calculated_result = st.session_state.input1 + st.session_state.input2 + 10
    
    # Setze das berechnete Ergebnis
    if st.session_state.result != calculated_result:
        st.session_state.result = calculated_result
        print("Updated Result in Backend:", st.session_state.result)

st.write("This infos are printed by streamlit")
st.write("input  1:", st.session_state.input1)
st.write("input 2:", st.session_state.input2)
st.write("result:", st.session_state.result)

# Rückgabe des Ergebnis an die React-Komponente direkt am Ende
# my_component.result = st.session_state.result